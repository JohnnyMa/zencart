<?php
/**
* PureBlackFree Template designed by 12leaves.com
* 12leaves.com - ecommerce webdesign services
* 
* Template Information File
*
* @package templateSystem
* @copyright Copyright 2008-2009 12leaves.com
* @copyright Copyright 2003-2005 Zen Cart Development Team
* @copyright Portions Copyright 2003 osCommerce
* @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
* @version $Id: template_info.php 2306 2008-01-09 21:34:28Z vlad $
 */
$template_name = 'BlackPureFree';
$template_version = 'Version 1.1';
$template_author = '<a href="http://www.12leaves.com" target="_blank">12leaves.com</a> &copy; 2008-2009';
$template_description = 'Template from 12leaves.com. Find more at our web site';
$template_screenshot = 'pure_black.png';
?>